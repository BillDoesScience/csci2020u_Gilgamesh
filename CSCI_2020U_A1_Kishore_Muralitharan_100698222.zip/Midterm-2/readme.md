# How to Run your Program:
1. Unzip the contents of the file into its own Directory
2. Ensure you have a version of Gradle Installed on your System
3. Ensure you have Java 16 Installed on your System as this program was built on that SDK
4. Open the Main Directory in your Command Interface of Choice
5. Run the gradle run command to build and execute the Program
   1. For Ease of use, It is recommended you open this project using IntelliJ because it can be configured to run this program eaisly